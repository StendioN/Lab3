package ua.kpi.comsys.io8118.ui.graphics

class GraphicsFragment {
}